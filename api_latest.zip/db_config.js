const DBConfig = {
  host: "127.0.0.1",
  port: 3306,
  database_name: "db_formation",
  database_username: "root",
  database_password: "",
  dialect: "mysql",
};

module.exports = DBConfig;
